const spaceURL = document.querySelector('.hero-unit-space-frontier');

spaceURL.addEventListener('click', function() {
  window.location = 'http://space.com/';
});

